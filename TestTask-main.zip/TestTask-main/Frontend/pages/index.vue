<template>
  <div>
    <v-container
      :key="align"
      class="grey lighten-5 mb-6"
    >
      <v-row
        :align="align"
        no-gutters
        style="height: 150px;"
        
      >
        <v-col >
            <v-text-field class="ml-16" label="Введите текст" v-model="textSearch"></v-text-field>
        </v-col>    
        <v-col cols="auto">
                <v-btn class="ml-5" @click="postTextApi()">Отправить заметку</v-btn>
        </v-col>
        <v-col>
                <v-btn class="ml-5" @click="loadData()">Получить список заметок</v-btn>
        </v-col>
        <v-list>
          <v-list-item-group color="primary">
            <v-list-item 
              v-for="text in textsList" :key="text">
                <v-list-item-content>
                  <v-list-item-title v-text="text.text"></v-list-item-title>
                </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
        </v-list>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import axios from "axios";

export default
{
  data: () =>
    ({
      el: '#card',
      align: 'center',
      textSearch: '',
      textsList: [],
      url:{
        getUrl: 'http://localhost:5000/api/webtext',
        postUrl: 'http://localhost:5000/api/webtext'
      }
    }),

  methods: {
    async loadData()
    {
      await axios
        .get('http://localhost:5000/api/webtext')
        .then(response => this.textsList = response.data)
    },

    postTextApi(){
      axios({
        method: 'post',
        url: this.url.postUrl,
        data:{
          text: this.textSearch
        }
      });
    }

  }

}
</script>

<style>

#btn-id{
  display:block;
  margin:auto;
}

#card-id{
  height: 500;
  width: 500;
  margin-left: 40%;
}

#progress_circular_id{
  display: block;
  margin: auto;
  visibility: visible;
}
</style>